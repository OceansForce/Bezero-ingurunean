const lista=[];

function form_gehitu(){
    
    lista.push(kontaktua={
        izena:"",
        abizena:"",
        telefonoak: [[]],
        tel_kant: 1
    });
    let index= lista.length;

    let formulario_kaxa= document.getElementById("formularioak");

    let formularioa= document.createElement("div");

    formularioa.innerHTML=`<form id="${index}">
            <label >Izena</label><br>
            <input name="izena" type="text" onchange="datuak_gehitu(${index})"><br>
            <label >Abizena</label><br>
            <input name="abizena" type="text" onchange="datuak_gehitu(${index})"><br>
            <label >Telefonoa</label><br>
            <input id="${index}1" type="tel" onchange="datuak_gehitu(${index})"><br>
            <button onclick="tel_gehitu(${index})">Telefonoa+</button>
        </form>`;
       
    formulario_kaxa.appendChild(formularioa);

}

function datuak_gehitu(index){
    let formularioa= document.forms[index];
    
    let izena= formularioa.izena.value; 
    let abizena= formularioa.abizena.value;
    let telefonoa= document.getElementById(index+"1");

    lista[index].izena=izena;
    lista[index].abizena=abizena;
    lista[index].telefonoa.push(telefonoa);
    
}