
function data(){
    gaur = new Date();
    kurtso_amaiera = new Date(2025, 5, 30);

    console.log(Math.round((kurtso_amaiera-gaur)/86400000));
}
