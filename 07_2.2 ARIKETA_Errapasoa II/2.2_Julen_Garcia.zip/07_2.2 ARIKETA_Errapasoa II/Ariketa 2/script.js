function batura(){
    let zenb=0;
    for (i=0; i<11; i++){
      zenb=zenb+i;
    }
    document.getElementById("a").innerHTML=zenb;
}