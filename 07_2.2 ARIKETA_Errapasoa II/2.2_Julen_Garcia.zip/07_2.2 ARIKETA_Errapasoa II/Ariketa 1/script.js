function bikoitiak(){
    for (i=0; i<101; i++){
        if (i!=0 && i%2==0){
            document.getElementById("a").innerHTML+=i+"-";
        }
    }
}