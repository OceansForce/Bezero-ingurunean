function zatigarri(){
    zenb= prompt("Zenbaki bat jarri");
    if (zenb%2==0){
        document.getElementById("a").innerHTML= "2rekin zatigarria da."
    }else{
         document.getElementById("a").innerHTML= "Ez da zatigarria."
    }
}