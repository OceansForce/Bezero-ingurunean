function idatzi1(){
    izena= prompt("Izena?");
    document.getElementById("1").innerHTML= "Kaixo "+izena;
       
}